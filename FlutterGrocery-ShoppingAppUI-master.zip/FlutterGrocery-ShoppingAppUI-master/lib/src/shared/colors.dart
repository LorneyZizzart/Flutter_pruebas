import 'package:flutter/material.dart';

 const Color bgColor = Color(0xffF4F7FA);
//  const Color primaryColor = Colors.green;
 const Color primaryColor = Color(0xff44c662);
 const Color white = Colors.white;
 const Color darkText = Colors.black54;
 const Color highlightColor = Colors.green;
