#!/bin/sh
exec flutter format lib/ test/