abstract class KeyStorageService {
  bool hasNotificationsEnabled;
}
