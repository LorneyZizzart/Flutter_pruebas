class RepositoryException implements Exception {
  final String message;

  const RepositoryException(this.message);
}
