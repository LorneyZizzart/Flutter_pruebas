enum ConnectivityStatus { Cellular, WiFi, Offline }
