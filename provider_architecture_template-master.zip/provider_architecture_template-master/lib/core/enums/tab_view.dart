/// Enum that defines a view for the [TabContainer]
enum TabView { Home, Settings }
