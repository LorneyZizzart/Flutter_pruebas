/// Model that a SnackBar in the [SnackBarManager] returns from the [SnackBarService]
abstract class SnackBarResponse {}
