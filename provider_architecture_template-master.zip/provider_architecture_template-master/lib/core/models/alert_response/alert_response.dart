/// Model that a dialog in the [DialogManager] returns from the [DialogService]
abstract class AlertResponse {}
