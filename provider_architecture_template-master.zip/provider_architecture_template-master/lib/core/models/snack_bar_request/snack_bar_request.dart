abstract class SnackBarRequest {}
