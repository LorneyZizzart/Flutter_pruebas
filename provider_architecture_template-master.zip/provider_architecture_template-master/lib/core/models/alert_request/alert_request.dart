/// Model that a dialog in the [DialogManager] accepts as input
abstract class AlertRequest {}
