/// File Paths and constants for flare animations
class Animations {
  Animations._();

  static const loader = 'assets/animations/loader.flr';
  static const loader_name = 'Aura';
}
