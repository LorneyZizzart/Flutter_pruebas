class AssetImages {
  static const logo = 'assets/images/logo.png';
}
