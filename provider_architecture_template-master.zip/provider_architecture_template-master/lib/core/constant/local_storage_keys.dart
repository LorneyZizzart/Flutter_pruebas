class LocalStorageKeys {
  static const posts = 'posts';
  static const users = 'users';
}
