---
name: Feature request
about: Suggest an idea for the app!
title: ''
labels: enhancement
assignees: urmilshroff

---

**Describe the feature you'd like**
A clear and concise description of what you want.

**Additional context**
Add any other context or screenshots about the feature request here.

**Ideas for implementation**
In case you have figured out a way to implement the feature but don't know how to code it in.
